# Machine Inventory App
This is the React app for managing machine parts inventory.
